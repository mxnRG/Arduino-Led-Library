#include "LedLibrary.h"

LedControl::LedControl(int pin1, int pin2, int pin3, int pin4) {
    ledPins[0] = pin1;
    ledPins[1] = pin2;
    ledPins[2] = pin3;
    ledPins[3] = pin4;
}

void LedControl::begin() {
    for (int i = 0; i < 4; i++) {
        pinMode(ledPins[i], OUTPUT);
    }
    allOff();
}

void LedControl::displayBinary(int number) {
    for (int i = 0; i < 4; i++) {
        digitalWrite(ledPins[i], (number >> i) & 0x01);
    }
}

void LedControl::generateRandNumber() {
    int randNumber = random(0, 16);
    displayBinary(randNumber);
}

void LedControl::upCount() {
    for (int i = 0; i <= 15; i++) {
        displayBinary(i);
        delay(2000);
    }
}

void LedControl::downCount() {
    for (int i = 15; i >= 0; i--) {
        displayBinary(i);
        delay(2000);
    }
}

void LedControl::shiftRight(int num, int shift_amount) {
    if (num < 1 || num > 15 || shift_amount < 1 || shift_amount > 4) return;
    displayBinary(num);
    delay(1000);

    for (int i = 0; i < shift_amount; i++) {
        num >>= 1;
        displayBinary(num);
        delay(1000);
    }
}

void LedControl::shiftLeft(int num, int shift_amount) {
    if (num < 1 || num > 15 || shift_amount < 1 || shift_amount > 4) return;
    displayBinary(num);
    delay(1000);

    for (int i = 0; i < shift_amount; i++) {
        num <<= 1;
        displayBinary(num & 0x0F);
        delay(1000);
    }
}

void LedControl::allOff() {
    for (int i = 0; i < 4; i++) {
        digitalWrite(ledPins[i], LOW);
    }
}

void LedControl::allOn() {
    for (int i = 0; i < 4; i++) {
        digitalWrite(ledPins[i], HIGH);
    }
}
