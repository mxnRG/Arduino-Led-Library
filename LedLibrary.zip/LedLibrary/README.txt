Created by:
Muhammad Mamoon
Syed M. Haroon
Talal A. Joyia

LED PINS (in order): 2,3,4,5 (Can be changed in your own implementation)

This is a basic Arduino library which can be used to control or perform different actions with 4 leds connected to a breadboard. This library contains a few functionalities, such as generating a number, counting upwards using leds, counting downwards using leds (in binary),
shift bits left and shift bits right (in binary), turn all LEDs on and all LEDs off.

Components required to run this library:

1x Arduino UNO
4x LED Pins